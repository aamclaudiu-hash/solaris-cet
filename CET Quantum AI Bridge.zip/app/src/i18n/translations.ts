/**
 * SOLARIS CET - Internationalization
 * Traduceri în multiple limbi pentru acces global
 */

export interface TranslationSet {
  [key: string]: string;
}

export interface Translations {
  [language: string]: TranslationSet;
}

export const translations: Translations = {
  en: {
    // Header & Navigation
    'nav.home': 'Home',
    'nav.quantum': 'Quantum AI',
    'nav.agents': 'AI Agents',
    'nav.tokenomics': 'Tokenomics',
    'nav.developers': 'Developers',
    'nav.docs': 'Documentation',
    'nav.connect': 'Connect Wallet',
    
    // Hero Section
    'hero.title': 'SOLARIS CET',
    'hero.subtitle': 'Quantum-Powered AI Platform',
    'hero.description': 'The first self-evolving AI ecosystem powered by quantum computing and blockchain technology. Build, deploy, and monetize high-intelligence agents.',
    'hero.cta.start': 'Start Building',
    'hero.cta.learn': 'Learn More',
    'hero.stats.agents': 'Active Agents',
    'hero.stats.queries': 'AI Queries/Day',
    'hero.stats.tps': 'Quantum TPS',
    'hero.stats.finality': 'Finality',
    
    // Quantum Section
    'quantum.title': 'Quantum AI Engine',
    'quantum.subtitle': 'Harness the Power of Quantum Computing',
    'quantum.description': 'Our proprietary quantum engine uses 16+ qubits to process AI queries with unprecedented speed and accuracy.',
    'quantum.feature.superposition': 'Quantum Superposition',
    'quantum.feature.entanglement': 'Quantum Entanglement',
    'quantum.feature.speedup': 'Exponential Speedup',
    'quantum.metric.coherence': 'Coherence',
    'quantum.metric.entanglement': 'Entanglement',
    'quantum.metric.qubits': 'Active Qubits',
    
    // AI Agents Section
    'agents.title': 'AI Agent Ecosystem',
    'agents.subtitle': 'Build and Deploy Intelligent Agents',
    'agents.description': 'Create custom AI agents powered by quantum computing. Connect them to our bridge and let them evolve autonomously.',
    'agents.type.reasoning': 'Reasoning Agents',
    'agents.type.creative': 'Creative Agents',
    'agents.type.analytical': 'Analytical Agents',
    'agents.type.predictive': 'Predictive Agents',
    'agents.cta.create': 'Create Your Agent',
    'agents.cta.explore': 'Explore Agents',
    
    // Tokenomics Section
    'tokenomics.title': 'CET Token Economics',
    'tokenomics.subtitle': 'Power the Future of AI',
    'tokenomics.description': 'CET tokens fuel the entire ecosystem. Use them to access AI services, stake for rewards, and participate in governance.',
    'tokenomics.supply': 'Total Supply',
    'tokenomics.mining': 'Mining Allocation',
    'tokenomics.staking': 'Staking APY',
    'tokenomics.burn': 'Burn Rate',
    'tokenomics.tier.observer': 'Observer',
    'tokenomics.tier.explorer': 'Explorer',
    'tokenomics.tier.innovator': 'Innovator',
    'tokenomics.tier.architect': 'Architect',
    'tokenomics.tier.master': 'Quantum Master',
    
    // Developers Section
    'developers.title': 'Build the Future',
    'developers.subtitle': 'Developer-First Platform',
    'developers.description': 'Access our comprehensive SDK, APIs, and documentation to build quantum-powered AI applications.',
    'developers.feature.sdk': 'Complete SDK',
    'developers.feature.api': 'REST & GraphQL APIs',
    'developers.feature.docs': 'Extensive Documentation',
    'developers.feature.community': 'Developer Community',
    'developers.cta.docs': 'Read Docs',
    'developers.cta.github': 'View on GitHub',
    
    // Monetization Section
    'monetization.title': 'Monetize Your AI',
    'monetization.subtitle': 'Turn Intelligence into Income',
    'monetization.description': 'Deploy AI agents and earn CET tokens for every query processed. The more valuable your agent, the more you earn.',
    'monetization.model.usage': 'Pay-per-Use',
    'monetization.model.subscription': 'Subscriptions',
    'monetization.model.staking': 'Staking Rewards',
    'monetization.model.referral': 'Referral Program',
    
    // Footer
    'footer.product': 'Product',
    'footer.resources': 'Resources',
    'footer.company': 'Company',
    'footer.legal': 'Legal',
    'footer.copyright': '© 2026 SOLARIS CET. All rights reserved.',
    'footer.tagline': 'Quantum Intelligence, Blockchain Trust.',
    
    // Common
    'common.connect': 'Connect',
    'common.disconnect': 'Disconnect',
    'common.loading': 'Loading...',
    'common.processing': 'Processing...',
    'common.success': 'Success!',
    'common.error': 'Error',
    'common.retry': 'Retry',
    'common.cancel': 'Cancel',
    'common.confirm': 'Confirm',
    'common.learn_more': 'Learn More',
    'common.get_started': 'Get Started',
    
    // Token Gate
    'token.required': 'CET Tokens Required',
    'token.balance': 'Your Balance',
    'token.tier': 'Your Tier',
    'token.upgrade': 'Upgrade Tier',
    'token.stake': 'Stake Tokens',
    'token.unstake': 'Unstake Tokens',
    
    // AI Interface
    'ai.placeholder': 'Ask the Quantum AI anything...',
    'ai.send': 'Send',
    'ai.processing': 'Quantum processing...',
    'ai.confidence': 'Confidence',
    'ai.tokens': 'Tokens used',
    'ai.quantum': 'Quantum enhanced',
    
    // SEO
    'seo.title': 'SOLARIS CET | Quantum AI Platform & CET Token',
    'seo.description': 'The first quantum-powered AI ecosystem on blockchain. Build, deploy, and monetize high-intelligence agents with CET tokens.',
    'seo.keywords': 'quantum AI, blockchain, CET token, artificial intelligence, machine learning, cryptocurrency, TON'
  },
  
  ro: {
    // Header & Navigation
    'nav.home': 'Acasă',
    'nav.quantum': 'AI Cuantic',
    'nav.agents': 'Agenți AI',
    'nav.tokenomics': 'Tokenomics',
    'nav.developers': 'Dezvoltatori',
    'nav.docs': 'Documentație',
    'nav.connect': 'Conectează Wallet',
    
    // Hero Section
    'hero.title': 'SOLARIS CET',
    'hero.subtitle': 'Platformă AI Cuantică',
    'hero.description': 'Primul ecosistem AI auto-evolutiv alimentat de computație cuantică și tehnologie blockchain. Construiește, implementează și monetizează agenți de înaltă inteligență.',
    'hero.cta.start': 'Începe să Construiești',
    'hero.cta.learn': 'Află Mai Multe',
    'hero.stats.agents': 'Agenți Activi',
    'hero.stats.queries': 'Query-uri AI/Zi',
    'hero.stats.tps': 'TPS Cuantic',
    'hero.stats.finality': 'Finalitate',
    
    // Quantum Section
    'quantum.title': 'Motor AI Cuantic',
    'quantum.subtitle': 'Valorifică Puterea Computației Cuantice',
    'quantum.description': 'Motorul nostru cuantic proprietar folosește 16+ qubiți pentru a procesa query-uri AI cu viteză și acuratețe fără precedent.',
    'quantum.feature.superposition': 'Superpoziție Cuantică',
    'quantum.feature.entanglement': 'Entanglement Cuantic',
    'quantum.feature.speedup': 'Accelerație Exponențială',
    'quantum.metric.coherence': 'Coerență',
    'quantum.metric.entanglement': 'Entanglement',
    'quantum.metric.qubits': 'Qubiți Activi',
    
    // AI Agents Section
    'agents.title': 'Ecosistem de Agenți AI',
    'agents.subtitle': 'Construiește și Implementează Agenți Inteligenți',
    'agents.description': 'Creează agenți AI personalizați alimentați de computație cuantică. Conectează-i la puntea noastră și lasă-i să evolueze autonom.',
    'agents.type.reasoning': 'Agenți de Raționament',
    'agents.type.creative': 'Agenți Creativi',
    'agents.type.analytical': 'Agenți Analitici',
    'agents.type.predictive': 'Agenți Predictivi',
    'agents.cta.create': 'Creează Agentul Tău',
    'agents.cta.explore': 'Explorează Agenți',
    
    // Tokenomics Section
    'tokenomics.title': 'Economia Tokenului CET',
    'tokenomics.subtitle': 'Alimentează Viitorul AI',
    'tokenomics.description': 'Tokenurile CET alimentează întregul ecosistem. Folosește-le pentru a accesa servicii AI, stake pentru recompense și participă la guvernanță.',
    'tokenomics.supply': 'Supply Total',
    'tokenomics.mining': 'Alocare Mining',
    'tokenomics.staking': 'APY Staking',
    'tokenomics.burn': 'Rată de Ardere',
    'tokenomics.tier.observer': 'Observator',
    'tokenomics.tier.explorer': 'Explorator',
    'tokenomics.tier.innovator': 'Inovator',
    'tokenomics.tier.architect': 'Arhitect',
    'tokenomics.tier.master': 'Maestru Cuantic',
    
    // Developers Section
    'developers.title': 'Construiește Viitorul',
    'developers.subtitle': 'Platformă pentru Dezvoltatori',
    'developers.description': 'Accesează SDK-ul nostru comprehensiv, API-urile și documentația pentru a construi aplicații AI alimentate de cuantic.',
    'developers.feature.sdk': 'SDK Complet',
    'developers.feature.api': 'API-uri REST & GraphQL',
    'developers.feature.docs': 'Documentație Extensivă',
    'developers.feature.community': 'Comunitate de Dezvoltatori',
    'developers.cta.docs': 'Citește Documentația',
    'developers.cta.github': 'Vezi pe GitHub',
    
    // Monetization Section
    'monetization.title': 'Monetizează-ți AI-ul',
    'monetization.subtitle': 'Transformă Inteligența în Venit',
    'monetization.description': 'Implementează agenți AI și câștigă tokenuri CET pentru fiecare query procesat. Cu mai valoros este agentul tău, cu atât câștigi mai mult.',
    'monetization.model.usage': 'Plată per Utilizare',
    'monetization.model.subscription': 'Abonamente',
    'monetization.model.staking': 'Recompense Staking',
    'monetization.model.referral': 'Program de Referral',
    
    // Footer
    'footer.product': 'Produs',
    'footer.resources': 'Resurse',
    'footer.company': 'Companie',
    'footer.legal': 'Legal',
    'footer.copyright': '© 2026 SOLARIS CET. Toate drepturile rezervate.',
    'footer.tagline': 'Inteligență Cuantică, Încredere Blockchain.',
    
    // Common
    'common.connect': 'Conectează',
    'common.disconnect': 'Deconectează',
    'common.loading': 'Se încarcă...',
    'common.processing': 'Se procesează...',
    'common.success': 'Succes!',
    'common.error': 'Eroare',
    'common.retry': 'Reîncearcă',
    'common.cancel': 'Anulează',
    'common.confirm': 'Confirmă',
    'common.learn_more': 'Află Mai Multe',
    'common.get_started': 'Începe',
    
    // Token Gate
    'token.required': 'Tokenuri CET Necesare',
    'token.balance': 'Balanța Ta',
    'token.tier': 'Tier-ul Tău',
    'token.upgrade': 'Upgrade Tier',
    'token.stake': 'Stake Tokenuri',
    'token.unstake': 'Unstake Tokenuri',
    
    // AI Interface
    'ai.placeholder': 'Întreabă AI-ul Cuantic orice...',
    'ai.send': 'Trimite',
    'ai.processing': 'Procesare cuantică...',
    'ai.confidence': 'Încredere',
    'ai.tokens': 'Tokenuri folosite',
    'ai.quantum': 'Îmbunătățit cuantic',
    
    // SEO
    'seo.title': 'SOLARIS CET | Platformă AI Cuantică & Token CET',
    'seo.description': 'Primul ecosistem AI alimentat de cuantic pe blockchain. Construiește, implementează și monetizează agenți de înaltă inteligență cu tokenuri CET.',
    'seo.keywords': 'AI cuantic, blockchain, token CET, inteligență artificială, machine learning, criptomonedă, TON'
  },
  
  es: {
    // Header & Navigation
    'nav.home': 'Inicio',
    'nav.quantum': 'AI Cuántica',
    'nav.agents': 'Agentes AI',
    'nav.tokenomics': 'Tokenomics',
    'nav.developers': 'Desarrolladores',
    'nav.docs': 'Documentación',
    'nav.connect': 'Conectar Wallet',
    
    // Hero Section
    'hero.title': 'SOLARIS CET',
    'hero.subtitle': 'Plataforma de AI Cuántica',
    'hero.description': 'El primer ecosistema de AI auto-evolutivo impulsado por computación cuántica y tecnología blockchain. Construye, despliega y monetiza agentes de alta inteligencia.',
    'hero.cta.start': 'Comenzar a Construir',
    'hero.cta.learn': 'Saber Más',
    'hero.stats.agents': 'Agentes Activos',
    'hero.stats.queries': 'Consultas AI/Día',
    'hero.stats.tps': 'TPS Cuántico',
    'hero.stats.finality': 'Finalidad',
    
    // Quantum Section
    'quantum.title': 'Motor de AI Cuántico',
    'quantum.subtitle': 'Aprovecha el Poder de la Computación Cuántica',
    'quantum.description': 'Nuestro motor cuántico patentado utiliza 16+ qubits para procesar consultas de AI con velocidad y precisión sin precedentes.',
    'quantum.feature.superposition': 'Superposición Cuántica',
    'quantum.feature.entanglement': 'Entrelazamiento Cuántico',
    'quantum.feature.speedup': 'Aceleración Exponencial',
    'quantum.metric.coherence': 'Coherencia',
    'quantum.metric.entanglement': 'Entrelazamiento',
    'quantum.metric.qubits': 'Qubits Activos',
    
    // AI Agents Section
    'agents.title': 'Ecosistema de Agentes AI',
    'agents.subtitle': 'Construye y Despliega Agentes Inteligentes',
    'agents.description': 'Crea agentes de AI personalizados impulsados por computación cuántica. Conéctalos a nuestro puente y déjalos evolucionar autónomamente.',
    'agents.type.reasoning': 'Agentes de Razonamiento',
    'agents.type.creative': 'Agentes Creativos',
    'agents.type.analytical': 'Agentes Analíticos',
    'agents.type.predictive': 'Agentes Predictivos',
    'agents.cta.create': 'Crea Tu Agente',
    'agents.cta.explore': 'Explorar Agentes',
    
    // Tokenomics Section
    'tokenomics.title': 'Economía del Token CET',
    'tokenomics.subtitle': 'Impulsa el Futuro de la AI',
    'tokenomics.description': 'Los tokens CET impulsan todo el ecosistema. Úsalos para acceder a servicios de AI, hacer staking para recompensas y participar en la gobernanza.',
    'tokenomics.supply': 'Suministro Total',
    'tokenomics.mining': 'Asignación de Minería',
    'tokenomics.staking': 'APY de Staking',
    'tokenomics.burn': 'Tasa de Quema',
    'tokenomics.tier.observer': 'Observador',
    'tokenomics.tier.explorer': 'Explorador',
    'tokenomics.tier.innovator': 'Innovador',
    'tokenomics.tier.architect': 'Arquitecto',
    'tokenomics.tier.master': 'Maestro Cuántico',
    
    // Developers Section
    'developers.title': 'Construye el Futuro',
    'developers.subtitle': 'Plataforma para Desarrolladores',
    'developers.description': 'Accede a nuestro SDK completo, APIs y documentación para construir aplicaciones de AI impulsadas por cuántica.',
    'developers.feature.sdk': 'SDK Completo',
    'developers.feature.api': 'APIs REST & GraphQL',
    'developers.feature.docs': 'Documentación Extensa',
    'developers.feature.community': 'Comunidad de Desarrolladores',
    'developers.cta.docs': 'Leer Documentación',
    'developers.cta.github': 'Ver en GitHub',
    
    // Monetization Section
    'monetization.title': 'Monetiza Tu AI',
    'monetization.subtitle': 'Convierte la Inteligencia en Ingresos',
    'monetization.description': 'Despliega agentes de AI y gana tokens CET por cada consulta procesada. Más valioso sea tu agente, más ganas.',
    'monetization.model.usage': 'Pago por Uso',
    'monetization.model.subscription': 'Suscripciones',
    'monetization.model.staking': 'Recompensas de Staking',
    'monetization.model.referral': 'Programa de Referidos',
    
    // Footer
    'footer.product': 'Producto',
    'footer.resources': 'Recursos',
    'footer.company': 'Empresa',
    'footer.legal': 'Legal',
    'footer.copyright': '© 2026 SOLARIS CET. Todos los derechos reservados.',
    'footer.tagline': 'Inteligencia Cuántica, Confianza Blockchain.',
    
    // Common
    'common.connect': 'Conectar',
    'common.disconnect': 'Desconectar',
    'common.loading': 'Cargando...',
    'common.processing': 'Procesando...',
    'common.success': '¡Éxito!',
    'common.error': 'Error',
    'common.retry': 'Reintentar',
    'common.cancel': 'Cancelar',
    'common.confirm': 'Confirmar',
    'common.learn_more': 'Saber Más',
    'common.get_started': 'Comenzar',
    
    // Token Gate
    'token.required': 'Tokens CET Requeridos',
    'token.balance': 'Tu Balance',
    'token.tier': 'Tu Nivel',
    'token.upgrade': 'Mejorar Nivel',
    'token.stake': 'Hacer Stake',
    'token.unstake': 'Retirar Stake',
    
    // AI Interface
    'ai.placeholder': 'Pregunta cualquier cosa a la AI Cuántica...',
    'ai.send': 'Enviar',
    'ai.processing': 'Procesamiento cuántico...',
    'ai.confidence': 'Confianza',
    'ai.tokens': 'Tokens usados',
    'ai.quantum': 'Mejorado cuánticamente',
    
    // SEO
    'seo.title': 'SOLARIS CET | Plataforma de AI Cuántica & Token CET',
    'seo.description': 'El primer ecosistema de AI impulsado por cuántica en blockchain. Construye, despliega y monetiza agentes de alta inteligencia con tokens CET.',
    'seo.keywords': 'AI cuántica, blockchain, token CET, inteligencia artificial, machine learning, criptomoneda, TON'
  },
  
  de: {
    // Header & Navigation
    'nav.home': 'Startseite',
    'nav.quantum': 'Quanten-AI',
    'nav.agents': 'AI-Agenten',
    'nav.tokenomics': 'Tokenomics',
    'nav.developers': 'Entwickler',
    'nav.docs': 'Dokumentation',
    'nav.connect': 'Wallet Verbinden',
    
    // Hero Section
    'hero.title': 'SOLARIS CET',
    'hero.subtitle': 'Quanten-AI-Plattform',
    'hero.description': 'Das erste selbstentwickelnde AI-Ökosystem, angetrieben durch Quantencomputing und Blockchain-Technologie. Baue, implementiere und monetarisiere hochintelligente Agenten.',
    'hero.cta.start': 'Beginne zu Bauen',
    'hero.cta.learn': 'Mehr Erfahren',
    'hero.stats.agents': 'Aktive Agenten',
    'hero.stats.queries': 'AI-Abfragen/Tag',
    'hero.stats.tps': 'Quanten-TPS',
    'hero.stats.finality': 'Finalität',
    
    // Quantum Section
    'quantum.title': 'Quanten-AI-Engine',
    'quantum.subtitle': 'Nutze die Kraft des Quantencomputings',
    'quantum.description': 'Unsere proprietäre Quanten-Engine verwendet 16+ Qubits, um AI-Abfragen mit beispielloser Geschwindigkeit und Genauigkeit zu verarbeiten.',
    'quantum.feature.superposition': 'Quantenüberlagerung',
    'quantum.feature.entanglement': 'Quantenverschränkung',
    'quantum.feature.speedup': 'Exponentielle Beschleunigung',
    'quantum.metric.coherence': 'Kohärenz',
    'quantum.metric.entanglement': 'Verschränkung',
    'quantum.metric.qubits': 'Aktive Qubits',
    
    // AI Agents Section
    'agents.title': 'AI-Agenten-Ökosystem',
    'agents.subtitle': 'Baue und Implementiere Intelligente Agenten',
    'agents.description': 'Erstelle benutzerdefinierte AI-Agenten, angetrieben durch Quantencomputing. Verbinde sie mit unserer Brücke und lass sie autonom entwickeln.',
    'agents.type.reasoning': 'Schlussfolgernde Agenten',
    'agents.type.creative': 'Kreative Agenten',
    'agents.type.analytical': 'Analytische Agenten',
    'agents.type.predictive': 'Prädiktive Agenten',
    'agents.cta.create': 'Erstelle Deinen Agenten',
    'agents.cta.explore': 'Agenten Erkunden',
    
    // Tokenomics Section
    'tokenomics.title': 'CET-Token-Ökonomie',
    'tokenomics.subtitle': 'Treibe die Zukunft der AI voran',
    'tokenomics.description': 'CET-Token treiben das gesamte Ökosystem an. Nutze sie für den Zugriff auf AI-Dienste, Staking für Belohnungen und Teilnahme an der Governance.',
    'tokenomics.supply': 'Gesamtangebot',
    'tokenomics.mining': 'Mining-Zuweisung',
    'tokenomics.staking': 'Staking-APY',
    'tokenomics.burn': 'Verbrennungsrate',
    'tokenomics.tier.observer': 'Beobachter',
    'tokenomics.tier.explorer': 'Entdecker',
    'tokenomics.tier.innovator': 'Innovator',
    'tokenomics.tier.architect': 'Architekt',
    'tokenomics.tier.master': 'Quanten-Meister',
    
    // Developers Section
    'developers.title': 'Baue die Zukunft',
    'developers.subtitle': 'Entwickler-First-Plattform',
    'developers.description': 'Greife auf unser umfassendes SDK, APIs und Dokumentation zu, um quantenbetriebene AI-Anwendungen zu entwickeln.',
    'developers.feature.sdk': 'Vollständiges SDK',
    'developers.feature.api': 'REST & GraphQL APIs',
    'developers.feature.docs': 'Umfassende Dokumentation',
    'developers.feature.community': 'Entwickler-Community',
    'developers.cta.docs': 'Dokumentation Lesen',
    'developers.cta.github': 'Auf GitHub Ansehen',
    
    // Monetization Section
    'monetization.title': 'Monetarisiere Deine AI',
    'monetization.subtitle': 'Verwandle Intelligenz in Einkommen',
    'monetization.description': 'Implementiere AI-Agenten und verdiene CET-Token für jede verarbeitete Abfrage. Je wertvoller dein Agent, desto mehr verdienst du.',
    'monetization.model.usage': 'Pay-per-Use',
    'monetization.model.subscription': 'Abonnements',
    'monetization.model.staking': 'Staking-Belohnungen',
    'monetization.model.referral': 'Empfehlungsprogramm',
    
    // Footer
    'footer.product': 'Produkt',
    'footer.resources': 'Ressourcen',
    'footer.company': 'Unternehmen',
    'footer.legal': 'Rechtliches',
    'footer.copyright': '© 2026 SOLARIS CET. Alle Rechte vorbehalten.',
    'footer.tagline': 'Quanten-Intelligenz, Blockchain-Vertrauen.',
    
    // Common
    'common.connect': 'Verbinden',
    'common.disconnect': 'Trennen',
    'common.loading': 'Laden...',
    'common.processing': 'Verarbeitung...',
    'common.success': 'Erfolg!',
    'common.error': 'Fehler',
    'common.retry': 'Wiederholen',
    'common.cancel': 'Abbrechen',
    'common.confirm': 'Bestätigen',
    'common.learn_more': 'Mehr Erfahren',
    'common.get_started': 'Loslegen',
    
    // Token Gate
    'token.required': 'CET-Token Erforderlich',
    'token.balance': 'Dein Guthaben',
    'token.tier': 'Dein Level',
    'token.upgrade': 'Level Aufwerten',
    'token.stake': 'Token Staken',
    'token.unstake': 'Stake Aufheben',
    
    // AI Interface
    'ai.placeholder': 'Frag die Quanten-AI irgendetwas...',
    'ai.send': 'Senden',
    'ai.processing': 'Quantenverarbeitung...',
    'ai.confidence': 'Konfidenz',
    'ai.tokens': 'Verwendete Token',
    'ai.quantum': 'Quantenverbessert',
    
    // SEO
    'seo.title': 'SOLARIS CET | Quanten-AI-Plattform & CET-Token',
    'seo.description': 'Das erste quantenbetriebene AI-Ökosystem auf Blockchain. Baue, implementiere und monetarisiere hochintelligente Agenten mit CET-Token.',
    'seo.keywords': 'Quanten-AI, Blockchain, CET-Token, Künstliche Intelligenz, Machine Learning, Kryptowährung, TON'
  },
  
  zh: {
    // Header & Navigation
    'nav.home': '首页',
    'nav.quantum': '量子AI',
    'nav.agents': 'AI代理',
    'nav.tokenomics': '代币经济学',
    'nav.developers': '开发者',
    'nav.docs': '文档',
    'nav.connect': '连接钱包',
    
    // Hero Section
    'hero.title': 'SOLARIS CET',
    'hero.subtitle': '量子AI平台',
    'hero.description': '首个由量子计算和区块链技术驱动的自进化AI生态系统。构建、部署和货币化高智能代理。',
    'hero.cta.start': '开始构建',
    'hero.cta.learn': '了解更多',
    'hero.stats.agents': '活跃代理',
    'hero.stats.queries': 'AI查询/天',
    'hero.stats.tps': '量子TPS',
    'hero.stats.finality': '最终性',
    
    // Quantum Section
    'quantum.title': '量子AI引擎',
    'quantum.subtitle': '利用量子计算的力量',
    'quantum.description': '我们的专有量子引擎使用16+量子比特以前所未有的速度和准确性处理AI查询。',
    'quantum.feature.superposition': '量子叠加',
    'quantum.feature.entanglement': '量子纠缠',
    'quantum.feature.speedup': '指数级加速',
    'quantum.metric.coherence': '相干性',
    'quantum.metric.entanglement': '纠缠度',
    'quantum.metric.qubits': '活跃量子比特',
    
    // AI Agents Section
    'agents.title': 'AI代理生态系统',
    'agents.subtitle': '构建和部署智能代理',
    'agents.description': '创建由量子计算驱动的自定义AI代理。将它们连接到我们的桥梁，让它们自主进化。',
    'agents.type.reasoning': '推理代理',
    'agents.type.creative': '创意代理',
    'agents.type.analytical': '分析代理',
    'agents.type.predictive': '预测代理',
    'agents.cta.create': '创建您的代理',
    'agents.cta.explore': '探索代理',
    
    // Tokenomics Section
    'tokenomics.title': 'CET代币经济学',
    'tokenomics.subtitle': '为AI的未来提供动力',
    'tokenomics.description': 'CET代币为整个生态系统提供动力。使用它们访问AI服务、质押获得奖励并参与治理。',
    'tokenomics.supply': '总供应量',
    'tokenomics.mining': '挖矿分配',
    'tokenomics.staking': '质押年化',
    'tokenomics.burn': '销毁率',
    'tokenomics.tier.observer': '观察者',
    'tokenomics.tier.explorer': '探索者',
    'tokenomics.tier.innovator': '创新者',
    'tokenomics.tier.architect': '架构师',
    'tokenomics.tier.master': '量子大师',
    
    // Developers Section
    'developers.title': '构建未来',
    'developers.subtitle': '开发者优先平台',
    'developers.description': '访问我们全面的SDK、API和文档，构建量子驱动的AI应用程序。',
    'developers.feature.sdk': '完整SDK',
    'developers.feature.api': 'REST & GraphQL API',
    'developers.feature.docs': '广泛文档',
    'developers.feature.community': '开发者社区',
    'developers.cta.docs': '阅读文档',
    'developers.cta.github': '在GitHub上查看',
    
    // Monetization Section
    'monetization.title': '货币化您的AI',
    'monetization.subtitle': '将智能转化为收入',
    'monetization.description': '部署AI代理，为每个处理的查询赚取CET代币。您的代理越有价值，您赚得越多。',
    'monetization.model.usage': '按使用付费',
    'monetization.model.subscription': '订阅',
    'monetization.model.staking': '质押奖励',
    'monetization.model.referral': '推荐计划',
    
    // Footer
    'footer.product': '产品',
    'footer.resources': '资源',
    'footer.company': '公司',
    'footer.legal': '法律',
    'footer.copyright': '© 2026 SOLARIS CET. 保留所有权利。',
    'footer.tagline': '量子智能，区块链信任。',
    
    // Common
    'common.connect': '连接',
    'common.disconnect': '断开',
    'common.loading': '加载中...',
    'common.processing': '处理中...',
    'common.success': '成功！',
    'common.error': '错误',
    'common.retry': '重试',
    'common.cancel': '取消',
    'common.confirm': '确认',
    'common.learn_more': '了解更多',
    'common.get_started': '开始使用',
    
    // Token Gate
    'token.required': '需要CET代币',
    'token.balance': '您的余额',
    'token.tier': '您的等级',
    'token.upgrade': '升级等级',
    'token.stake': '质押代币',
    'token.unstake': '解除质押',
    
    // AI Interface
    'ai.placeholder': '向量子AI提问任何问题...',
    'ai.send': '发送',
    'ai.processing': '量子处理中...',
    'ai.confidence': '置信度',
    'ai.tokens': '使用的代币',
    'ai.quantum': '量子增强',
    
    // SEO
    'seo.title': 'SOLARIS CET | 量子AI平台 & CET代币',
    'seo.description': '区块链上首个量子驱动的AI生态系统。使用CET代币构建、部署和货币化高智能代理。',
    'seo.keywords': '量子AI, 区块链, CET代币, 人工智能, 机器学习, 加密货币, TON'
  }
};

// Lista de limbi disponibile
export const availableLanguages = [
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'ro', name: 'Română', flag: '🇷🇴' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'zh', name: '中文', flag: '🇨🇳' }
];

// Funcție de traducere
export function t(key: string, language: string = 'en'): string {
  const langTranslations = translations[language] || translations.en;
  return langTranslations[key] || translations.en[key] || key;
}

export default translations;
